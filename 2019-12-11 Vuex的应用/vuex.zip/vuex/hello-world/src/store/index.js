import Vue from 'vue'//引入vue
import Vuex from 'vuex'//引入vuex
//使用
Vue.use(Vuex);
//创建实例
const store = new Vuex.Store({
    state:{
        count:1
    },
    getters:{
        getStateCount(state){
            return state.count+1;
        }
    },
    mutations:{
        addFun(state){
            state.count+=1;
        },
        subFun(state,n){
            state.count-=n;
        }
    },
    actions:{
        add(context){
            context.commit('addFun');
        },
        sub(context,n){
            context.commit('subFun',n);
        }
    }
})

export default store;