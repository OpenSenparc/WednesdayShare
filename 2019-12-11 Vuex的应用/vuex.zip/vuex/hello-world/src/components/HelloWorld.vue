<template>
  <div class="hello">
    <h1>我是页面上获取的值：{{$store.state.count}}</h1>
    <h1>我是从getters获取的值：{{$store.getters.getStateCount}}</h1>

    <p>count的值:{{$store.state.count}}</p>
    <button @click="addFun">+ </button>
    <button @click="subFun"> - </button>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  },
  methods:{
    addFun(){
      this.$store.commit('addFun');
      // this.$store.dispatch('add');
    },
    subFun(){
      this.$store.commit('subFun');
      // var n = 10;
      // this.$store.dispatch('sub',n);
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
